You can download the original MP3s from http://www.archive.org/details/Basfar


http://www.versebyversequran.com/

