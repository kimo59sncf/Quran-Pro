Note from Verse By Verse Quran
This timings file may not work for you as we used a very specific recitation found on www.hidayahonline.org.  There were some problems and we tried to fix it by doing the following:

We have the original files for the below chapters if you still need them
If you want to use the java script that we created to split them, you will need to rename these to 001.txt, 002.txt, etc..
-------------------------------------------------------------------------------------------------------------------------
Original note from the people who split it (AttaqwaSoft on Rentacoder)


Assalamo aleikom,


You will find attached 2 folders: 

1- Timing files: which contains the timing files of all chapters
2- Extracted MP3s from Parts: which contains MP3s we had to extract from the parts files due to errors in the chapters files.


- The Chapters we had to extract from parts because of errors are :
 010 - Yunnus      (the file jumps from verse 29 to verse 52)
 017 - Al-Esraa    (the file ends in the middle of verse 35)
 041 - Fussellat   (sound cut at verse 25)
 059 - Al-Hashr    (sound cut at verse 7) 
 077 - Al-Mursalat (sound cut at verse 50)

Also please note that:

- Chapter 036-Yasseen has a sound cut at verse 58, and the same cut exists in the part, so we couldn't fix it.

- Chapter 041-Fussellat was one of the extracted chapters, as mentioned above, but, in the part, it does not start with the Bassmallah 'Besm Allah alrahman alraheem', and that's why you'll find the extracted chapter without it.

- Some of the chapters starts with the Este'aza (A'ooz bellah men al shaytan al rajeem), and some doesn't. We don't know if you are going to use it or not, so we put a breakpoint after each Este'aza.



Jazaka Allahu Khairan Katheeran and it really was a pleasure and honour working with you on this project and if you need any adjustments made to our work 
please don't hesitate to contact us you already have our mail: AttaqwaSoft@gmail.com
